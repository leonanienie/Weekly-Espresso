# 资讯来源清单

## AI 科技媒体（英文）

| 来源 | 网址 | 搜索策略 |
|------|------|---------|
| TechCrunch | techcrunch.com | WebSearch `site:techcrunch.com AI` |
| The Verge | theverge.com | WebSearch `site:theverge.com AI technology` |
| Hacker News | news.ycombinator.com | WebSearch `Hacker News AI top stories today` |
| Ars Technica | arstechnica.com | WebSearch `site:arstechnica.com AI` |
| MIT Technology Review | technologyreview.com | WebSearch `site:technologyreview.com AI` |
| VentureBeat | venturebeat.com | WebSearch `site:venturebeat.com AI` |

## AI 科技媒体（中文）

| 来源 | 网址 | 搜索策略 |
|------|------|---------|
| 机器之心 | jiqizhixin.com | WebSearch `site:jiqizhixin.com` |
| 量子位 | qbitai.com | WebSearch `site:qbitai.com` |
| 36氪 | 36kr.com | WebSearch `site:36kr.com AI` |
| 虎嗅 | huxiu.com | WebSearch `site:huxiu.com AI` |

## 综合中文新闻

| 来源 | 网址 | 搜索策略 |
|------|------|---------|
| 新浪科技 | tech.sina.com.cn | WebSearch `site:tech.sina.com.cn` |
| 澎湃新闻 | thepaper.cn | WebSearch `site:thepaper.cn AI 科技` |
| 网易科技 | tech.163.com | WebSearch `site:tech.163.com` |
| 腾讯科技 | tech.qq.com | WebSearch `site:tech.qq.com` |

## 企业官网

对于重点企业，优先查看其官方 Newsroom / Press Release 页面。部分企业有 RSS 或新闻列表页面可以直接抓取。

## 搜索技巧

1. **时效限定**：搜索时加上当前日期或 `past 24 hours` 限定
2. **去重**：同一事件被多家媒体报道的，优先选择信息最完整的来源
3. **英文转中文**：英文新闻在摘要中翻译为中文，保留关键英文术语
4. **企业新闻**：优先搜索有实质产品/技术/合作动态的企业，纯股价/人事变动（非CEO级别）可忽略
