# 设计规范

## 配色方案

| 角色 | 色值 | 用途 |
|------|------|------|
| 主色 | `#FFB6C1` (Light Pink) | 强调元素、按钮、横幅、hover状态 |
| 主色深 | `#E8929E` | 统计数字、链接文字 |
| 主色浅 | `#FFF0F3` | 标签背景、分隔线 |
| 背景 | `#FFF5F6` | 页面全局背景 |
| 卡片 | `#FFFFFF` | 资讯卡片背景 |
| 正文 | `#2D2D2D` | 标题、摘要正文 |
| 辅助文字 | `#6B6B6B` | 摘要段落 |
| 弱化文字 | `#999999` | 时间、来源标注 |

## 标签颜色映射

| 标签类别 | 背景色 | 文字色 | 示例标签 |
|---------|--------|--------|---------|
| AI/大模型 | `#EDE9FE` | `#7C3AED` | `#AI` `#大模型` `#AGI` `#深度学习` |
| 芯片/算力 | `#DBEAFE` | `#2563EB` | `#AI芯片` `#GPU` `#算力` `#半导体` |
| 自动驾驶/新能源车 | `#D1FAE5` | `#059669` | `#自动驾驶` `#新能源车` `#FSD` |
| 能源 | `#FEF3C7` | `#D97706` | `#新能源` `#光伏` `#储能` `#氢能` |
| 产品发布 | `#FCE7F3` | `#DB2777` | `#产品发布` `#新品` `#发布` |
| 投融资 | `#E0E7FF` | `#4F46E5` | `#投融资` `#融资` `#IPO` `#收购` |
| 政策法规 | `#FEE2E2` | `#DC2626` | `#政策法规` `#监管` `#合规` |
| 企业合作 | `#CCFBF1` | `#0D9488` | `#企业合作` `#战略合作` `#联合` |
| 机器人 | `#F3E8FF` | `#9333EA` | `#机器人` `#人形机器人` `#具身智能` |
| 云计算 | `#E0F2FE` | `#0284C7` | `#云计算` `#SaaS` |
| 其他 | `#F5F5F5` | `#737373` | 未分类标签 |

## 卡片设计规范

- 圆角半径：14px
- 阴影：`0 2px 12px rgba(255, 182, 193, 0.15)`
- Hover 阴影：`0 6px 24px rgba(255, 182, 193, 0.28)`
- 卡片最小高度：自适应内容
- 桌面端：双列网格（`minmax(480px, 1fr)`）
- 移动端（<600px）：单列
- 卡片间距：18px
- 内边距：22px 24px

## 排版规范

- 字体栈：`-apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif`
- 标题字号：1.08em，font-weight 700
- 摘要字号：0.92em，line-height 1.7
- 标签字号：0.75em
- 元信息字号：0.8em

## 卡片 HTML 结构

每个卡片按以下结构生成并插入模板的 `__CARDS__` 占位符：

```html
<div class="card" data-tags="ai,大模型" tabindex="0">
  <div class="card-tags">
    <span class="tag tag-ai">#大模型</span>
    <span class="tag tag-product">#产品发布</span>
  </div>
  <div class="card-title">资讯标题</div>
  <div class="card-summary">50-100字中文摘要，说明发生了什么以及为什么重要。</div>
  <div class="card-meta">
    <span class="card-source">
      <span class="card-source-icon">📰</span>
      <span>来源名称 · 时间</span>
    </span>
    <a class="card-link" href="原文URL" target="_blank" rel="noopener">查看原文 →</a>
  </div>
</div>
```

## 标签筛选栏

每个唯一标签生成一个筛选按钮，格式：

```html
<span class="tag-filter" data-tag="ai">#大模型<span class="count">3</span></span>
```

`data-tag` 值使用标签的英文 key（如 `ai`、`chip`、`auto`、`product`），与卡片的 `data-tags` 中的值对应。
