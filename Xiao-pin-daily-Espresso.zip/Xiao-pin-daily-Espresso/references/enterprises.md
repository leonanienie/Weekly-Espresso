# 重点企业清单

共 100+ 家企业/机构，按行业分组。搜索时优先搜索近期有重大动态的企业。

---

## 金融 / 银行 / 保险

| 企业 | 官网 | 关注领域 | 搜索关键词 |
|------|------|---------|-----------|
| 中国投资有限责任公司 | china-inv.cn | 海外投资、AI投资 | 中投公司 AI 投资 |
| 中国工商银行 | icbc.com.cn | 金融科技、AI+银行 | 工商银行 金融科技 AI |
| 中国农业银行 | abchina.com | 金融科技、数字化转型 | 农业银行 AI 数字化 |
| 中国建设银行 | ccb.com | 金融科技、AI+银行 | 建设银行 金融科技 |
| 中国银行 | boc.cn | 金融科技、跨境金融 | 中国银行 AI 数字化 |
| 交通银行 | bankcomm.com | 金融科技、数字化转型 | 交通银行 金融科技 |
| 中国农业发展银行 | adbc.com.cn | 政策性金融 | 农发行 数字化 |
| 中国进出口银行 | eximbank.gov.cn | 政策性金融 | 进出口银行 最新 |
| 平安银行 | bank.pingan.com | 金融科技、AI+零售银行 | 平安银行 AI 科技 |
| 中国信达资产管理 | cinda.com.cn | 不良资产、金融科技 | 中国信达 最新 |
| 中国人寿 | chinalife.com.cn | 保险科技、AI+保险 | 中国人寿 AI 科技 |
| 中国人民保险集团 | picc.com.cn | 保险科技、数字化 | 中国人保 AI 数字化 |
| 中国出口信用保险公司 | sinosure.com.cn | 政策性保险 | 中国信保 最新 |
| 中国银联 | unionpay.com | 支付科技、AI+支付 | 银联 AI 支付 |
| 中国国际金融（中金） | cicc.com | 投行、AI+金融 | 中金公司 AI 投资 |
| 阳光保险集团 | sinosig.com | 保险科技 | 阳光保险 科技 |
| 四川银行 | scbank.cn | 区域金融 | 四川银行 数字化 |
| 华彬投资（中国） | — | 金融投资 | 华彬投资 最新 |

---

## 能源 / 化工 / 电力

| 企业 | 官网 | 关注领域 | 搜索关键词 |
|------|------|---------|-----------|
| 中石油（中国石油） | petrochina.com.cn | 能源AI、昆仑大模型 | 中石油 AI 昆仑大模型 |
| 中石化（中国石化） | sinopec.com | 数智石化、AI+炼化 | 中石化 AI 数字化 |
| 国家能源集团 | ceic.com | 能源AI、发电大模型 | 国家能源集团 AI |
| 中国华能集团 | chng.com.cn | 智慧能源、AI+电力 | 华能集团 AI 能源 |
| 南方电网 | csg.cn | AI+电力调度、大瓦特模型 | 南方电网 大瓦特 AI |
| 中海油（中国海油） | cnooc.com.cn | 海能AI、智慧油田 | 中海油 AI 数字化 |
| 中国广核集团 | cgnpc.com.cn | AI+核能、数字化 | 中广核 AI 数字化 |
| SABIC（沙特基础工业） | sabic.com | 化工新材料、可持续发展 | SABIC news |
| 沙特阿美（Saudi Aramco） | aramco.com | 能源转型、氢能、投资 | Saudi Aramco AI digital |
| 中国能建 | ceec.net.cn | 新能源、储能、绿色基建 | 中国能建 新能源 |
| 隆基绿能 | longi.com | 光伏、氢能、绿色能源 | 隆基绿能 光伏 BC |
| 明阳集团 | myse.com.cn | 风电、海洋能源 | 明阳集团 风电 |
| 天合光能 | trinasolar.com | 光伏、储能、钙钛矿 | 天合光能 储能 |
| 晶科能源 | jinkosolar.com | 光伏、储能 | 晶科能源 储能 |
| 天齐锂业 | tianqilithium.com | 锂资源、新能源材料 | 天齐锂业 最新 |
| 江西赣锋锂业 | ganfenglithium.com | 锂资源、电池材料 | 赣锋锂业 最新 |
| 远东控股集团 | fangdong.com | 新能源电缆、储能 | 远东控股 新能源 |
| 湖南裕能新能源 | — | 磷酸铁锂、新能源电池 | 湖南裕能 最新 |
| 美国艾柯斯科能源 | — | 能源投资 | 艾柯斯科 能源 |
| 天津荣程祥泰 | — | 钢铁、新能源转型 | 荣程祥泰 新能源 |
| 俄罗斯天然气工业 | gazprom.com | 天然气、能源出口 | Gazprom news energy |

---

## 汽车 / 新能源

| 企业 | 官网 | 关注领域 | 搜索关键词 |
|------|------|---------|-----------|
| 比亚迪 | byd.com | 电动车、电池、半导体 | 比亚迪 最新 |
| 特斯拉 | tesla.com | 电动车、FSD、机器人 | Tesla news |
| 宁德时代 | catl.com | 动力电池、储能 | 宁德时代 CATL |
| 重庆赛力斯 | seres.cn | 问界、华为合作 | 赛力斯 问界 |
| 吉利汽车 | geely.com | 智能驾驶、新能源 | 吉利汽车 智能 |
| 广汽集团 | gac.com.cn | 智能网联、新能源 | 广汽集团 新能源 AI |
| 现代汽车集团 | hyundai.com | 自动驾驶、机器人、AI工厂 | Hyundai AI robot |

---

## AI / 科技 / 通信

| 企业 | 官网 | 关注领域 | 搜索关键词 |
|------|------|---------|-----------|
| 英伟达（NVIDIA） | nvidia.com | GPU、AI芯片、CUDA | NVIDIA AI chip news |
| 微软 | microsoft.com | Azure AI、Copilot、OpenAI | Microsoft AI news |
| Deepseek | deepseek.com | 大模型、AGI | Deepseek news |
| 阿里巴巴 | alibaba.com | 通义千问、云计算 | 阿里巴巴 AI 通义 |
| 百度集团 | baidu.com | 文心一言、自动驾驶 | 百度 AI 文心 |
| 商汤科技 | sensetime.com | 计算机视觉、大模型 | 商汤科技 AI |
| 科大讯飞 | iflytek.com | 语音AI、教育AI | 科大讯飞 星火 |
| 宇树科技 | unitree.com | 人形机器人、四足机器人 | 宇树科技 机器人 |
| 联想集团 | lenovo.com | AI PC、智能设备 | 联想 AI PC |
| 韩国三星 | samsung.com | 半导体、AI手机 | Samsung AI semiconductor |
| 韩国SK集团 | sk.com | 半导体、AI投资 | SK Group AI |
| 中兴通讯 | zte.com.cn | 5G-A、AI基础设施、算力 | 中兴通讯 AI 算力 |
| 荣耀终端 | honor.com | AI手机、折叠屏 | 荣耀 AI 手机 |
| vivo | vivo.com | AI手机、影像技术 | vivo AI 手机 |
| 高通（Qualcomm） | qualcomm.com | 移动芯片、AI终端 | Qualcomm AI chip |
| 爱立信（Ericsson） | ericsson.com | 5G、通信AI | Ericsson AI 5G |
| 威盛电子（VIA） | via.com.tw | 芯片、边缘AI | 威盛电子 AI |
| 宏达通讯（HTC） | htc.com | VR/AR、AI | HTC AI VR |
| 第四范式 | 4paradigm.com | 企业级AI平台 | 第四范式 AI |
| 上海智臻智能（小i） | xiaoi.com | 智能客服、认知智能 | 智臻智能 AI |
| 希迪智驾 | ciDi.com | 自动驾驶、车路协同 | 希迪智驾 自动驾驶 |
| 北京猿力教育 | yuanfudao.com | AI+教育 | 猿力教育 AI |
| 中控技术 | supcon.com | 工业AI、流程自动化 | 中控技术 AI 工业 |

---

## 消费 / 零售 / 食品

| 企业 | 官网 | 关注领域 | 搜索关键词 |
|------|------|---------|-----------|
| 五粮液 | wuliangye.com.cn | 数字化转型、品牌 | 五粮液 最新 |
| 伊利集团 | yili.com | 智慧乳业、数字化 | 伊利 最新动态 |
| 椰树集团 | — | 品牌动态 | 椰树 最新 |
| 晨光文具 | mg-pen.com | 品牌创新 | 晨光文具 最新 |
| 百胜中国 | yumchina.com | AI+餐饮、供应链数字化 | 百胜中国 AI |
| 中国全聚德 | quanjude.com.cn | 老字号数字化 | 全聚德 数字化 |
| 华彬投资（红牛中国） | — | 快消、品牌 | 华彬 红牛 最新 |

---

## 物流 / 航运 / 航空

| 企业 | 官网 | 关注领域 | 搜索关键词 |
|------|------|---------|-----------|
| 中远海运集团 | coscoshipping.com | 智慧航运、绿色物流 | 中远海运 最新 |
| 顺丰集团 | sf-express.com | 无人机配送、智慧物流 | 顺丰 科技 |
| 中集集团 | cimc.com | 智能装备、冷链 | 中集集团 最新 |
| 中国南方航空 | csair.com | AI+民航、智慧出行 | 南方航空 AI 数字化 |

---

## 重工 / 制造 / 钢铁

| 企业 | 官网 | 关注领域 | 搜索关键词 |
|------|------|---------|-----------|
| 中国中车 | crrcgc.cc | 轨道交通、智能装备 | 中国中车 AI 智造 |
| 三一重工 | sany.com.cn | 智能制造、工业AI | 三一重工 AI 智造 |
| 中联重科 | zoomlion.com | 智能制造、工业AI | 中联重科 AI |
| 湖南钢铁集团 | — | 钢铁、智能制造 | 湖南钢铁 最新 |
| 玖龙纸业 | ndpaper.com | 造纸、循环经济 | 玖龙纸业 最新 |
| 桐昆集团 | tongkun.com.cn | 化纤、新材料 | 桐昆集团 最新 |
| 新凤鸣集团 | xinfengming.com | 化纤、新材料 | 新凤鸣 最新 |
| 中国巨石 | jushi.com | 玻纤、新材料 | 中国巨石 最新 |
| 辛集澳森特钢 | — | 特钢、高端制造 | 澳森特钢 最新 |
| 久立集团 | jiuli.com | 不锈钢管、特种材料 | 久立集团 最新 |
| 远大科技集团 | broad.com | 非电空调、可持续建筑 | 远大科技 最新 |

---

## 综合 / 其他

| 企业 | 官网 | 关注领域 | 搜索关键词 |
|------|------|---------|-----------|
| 阿斯利康（AstraZeneca） | astrazeneca.com | AI制药、数字医疗 | AstraZeneca AI digital |
| 福德士河（Fortescue） | fortescue.com | 绿色矿业、氢能 | Fortescue green energy |
| 尚亦城集团 | — | 智慧城市、文化科技 | 尚亦城 最新 |
| 海垦集团 | — | 智慧农业 | 海垦 最新 |
| NBC Universal | nbcuniversal.com | AI+媒体、流媒体 | NBC Universal AI |
| 中交集团 | ccccltd.cn | 智慧基建 | 中交集团 最新 |
| SpaceX | spacex.com | 星舰、星链 | SpaceX news |
| 正大集团（CP Group） | cpgroup.cn | 农业科技、AI+农牧 | 正大集团 AI |
| 金光集团（APP） | app.com.cn | 纸业、AI+制造 | 金光集团 最新 |
| 新加坡金鹰集团 | rgei.com | 资源、能源 | 金鹰集团 最新 |
| 强生（中国） | jnj.com.cn | 医疗AI、数字健康 | 强生 AI 数字健康 |
| 赢创工业（Evonik） | evonik.com | 特种化工、新材料 | Evonik AI digital |
| 默克（中国） | merckgroup.com | 医药健康、AI | 默克中国 最新 |
| PayPal | paypal.com | AI+支付、金融科技 | PayPal AI 支付 |
| 波士顿咨询（BCG） | bcg.com | AI咨询、数字化转型 | BCG AI consulting |
| 毕马威（KPMG） | kpmg.com | AI审计、咨询 | KPMG AI |
| 野村控股 | nomura.com | AI+金融、投资 | Nomura AI |
| 欧力士集团 | orix.co.jp | 金融、投资 | 欧力士 最新 |
| 三菱商事 | mitsubishicorp.com | 综合商社、AI投资 | 三菱商事 AI |
| 韩华生命保险 | hanwhalife.com | 保险科技 | 韩华生命 AI |
| 中电控股（CLP） | clpgroup.com | 电力、新能源 | 中电控股 最新 |
| 广州白云山医药 | gybys.com.cn | 中药AI、数字医疗 | 白云山 数字化 |
| 广州越秀集团 | yuexiu.com | 金融、地产、农业 | 越秀集团 最新 |
| 香港太古集团 | swire.com | 地产、航空、饮料 | 太古集团 最新 |
| 亿达控股 | yidaholdings.com | 软件园、IT服务 | 亿达 最新 |
| 宜宾丝丽雅集团 | — | 纤维、新材料 | 丝丽雅 最新 |
| 湖南农业发展投资 | — | 农业科技 | 湖南农业投资 最新 |
| 上海玫克生储能 | — | 储能、新能源 | 玫克生 储能 |
| 北京新氧科技 | soyoung.com | AI+医美 | 新氧 AI 医美 |
| 慈铭健康体检 | ciming.com | AI+体检、数字健康 | 慈铭 AI 健康 |
| 58到家 | daojia.com | AI+家政、O2O | 58到家 AI |
| 稻草熊娱乐 | — | AI+影视 | 稻草熊 AI 内容 |
| 罗兰贝格（中国） | rolandberger.com | 战略咨询、AI | 罗兰贝格 AI |
| 北京澳电电讯 | — | 电信技术服务 | 澳电 电讯 |
| 新疆投资发展集团 | — | 区域经济、资源 | 新疆投资 最新 |
| 新疆有色金属集团 | — | 矿业、有色 | 新疆有色 最新 |
| 新疆农牧业投资 | — | 农牧业 | 新疆农牧 最新 |
| 南丰发展 | — | 地产、综合 | 南丰发展 最新 |
| 汤臣集团 | — | 地产、综合 | 汤臣集团 最新 |
| 九圣禾控股 | — | 种业、农业科技 | 九圣禾 种业 |
| 新疆商贸物流集团 | — | 商贸物流 | 新疆商贸物流 最新 |
| 自贡灯彩文化 | — | 文旅、非遗 | 自贡灯彩 最新 |
| 华瑞世纪控股 | — | 综合投资 | 华瑞世纪 最新 |
| 苏州青骐骥科技 | — | 科技、新能源 | 青骐骥 最新 |
| 新疆阿比德控股 | — | 农业、食品 | 阿比德 最新 |

---

## 搜索优先级

1. **必搜（每期必查）**：NVIDIA、Microsoft、Tesla、SpaceX、比亚迪、Deepseek、阿里巴巴、百度、宁德时代、三星、SK集团、中石油、中石化、国家能源集团、南方电网、中兴通讯
2. **高频（每2-3期查一次）**：隆基绿能、晶科能源、天合光能、科大讯飞、宇树科技、联想、现代汽车、四大银行、南方航空、百胜中国、阿斯利康、广汽集团、NBC Universal
3. **触发式（有重大事件时深挖）**：其余企业

实际搜索时可按优先级合理分配搜索次数，确保总搜索量可控。
